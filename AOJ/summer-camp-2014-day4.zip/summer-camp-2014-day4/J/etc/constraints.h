const int N_MIN=3,N_MAX=100;
const int M_MIN=1,M_MAX=100;
const int X_MIN=-100,X_MAX=100;
const int Y_MIN=X_MIN, Y_MAX=X_MAX;
const int R_MIN=1,R_MAX=100;

const double DIST_EPS=1e-5;
const double AREA_EPS=1e-3;
